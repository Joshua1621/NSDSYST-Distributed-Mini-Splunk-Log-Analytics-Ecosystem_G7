# Distributed Mini-Splunk Log Analytics Ecosystem

**Authors:** [Group member names]  
**Course:** NSDSYST  
**Institution:** [Institution name]

## Abstract

This project implements a distributed Mini-Splunk log analytics ecosystem for ingesting,
parsing, storing, and querying syslog records across decoupled services. The system uses
Python-based client and service components, RabbitMQ for asynchronous inter-process
communication, three containerized worker nodes for distributed log parsing, and a
MongoDB sharded cluster for partitioned storage and distributed querying. The gateway
layer is split into an Ingest API and a Query API to improve fault isolation. Experimental
testing demonstrates core search functionality and provides a chaos-test procedure for
validating worker recovery, duplicate prevention, and zero data loss under failure.

**Index Terms**--distributed systems, log analytics, RabbitMQ, MongoDB sharding,
container orchestration, fault tolerance.

## I. Introduction

Modern log analytics systems must process large volumes of machine-generated events
without relying on a single monolithic service. A centralized design can become a
bottleneck and may lose availability when one component fails. This project addresses
that problem by designing a decoupled distributed architecture for syslog ingestion and
search.

The objective is to build a resilient Mini-Splunk ecosystem that accepts raw syslog files
from a command-line forwarder, distributes ingestion work through middleware, parses
logs using worker nodes, stores parsed records in a partitioned data layer, and supports
distributed queries through a search head. The implementation aligns with the course
outcomes by demonstrating distributed architecture design, middleware-based
communication, containerized deployment, state coordination, and fault-tolerance
testing.

## II. Algorithms and Implementation

### A. System Architecture

The system is composed of six main layers:

1. **Forwarder CLI:** A Python command-line client sends raw syslog files and query
   commands over HTTP. It supports one-shot commands and an interactive prompt through
   `main.py`.
2. **Ingest API:** Receives `INGEST` requests and publishes durable ingestion jobs to
   RabbitMQ.
3. **RabbitMQ Middleware:** Provides asynchronous communication and workload
   distribution through a durable direct exchange and queue.
4. **Worker Nodes:** Three containerized worker services consume from the same queue as
   competing consumers. Each worker parses syslog lines and writes structured documents
   to MongoDB.
5. **Query API / Search Head:** Receives search and purge commands and queries the
   distributed MongoDB cluster through the `mongos` router. It also exposes `/logs` and
   `/nodes` browser views for demonstration.
6. **MongoDB Sharded Cluster:** Stores parsed logs in a sharded `minisplunk.logs`
   collection. The cluster contains config servers, two shard replica sets, and a `mongos`
   query router.

**Figure 1:** [Insert architecture diagram here.]

The gateway layer is intentionally split into separate Ingest API and Query API
containers. This still follows the search-head/gateway role, but gives better fault
isolation: if the Query API is unavailable, ingestion can still enqueue work in RabbitMQ;
if the Ingest API is unavailable, already indexed logs can still be searched.

### B. Inter-Process Communication (IPC)

The system uses two communication mechanisms. First, the CLI communicates with the APIs
through HTTP. `INGEST` requests are sent to the Ingest API, while `QUERY` and `PURGE`
requests are sent to the Query API. Second, ingestion jobs are distributed using RabbitMQ.

RabbitMQ uses a durable direct exchange named `minisplunk.direct`, a durable queue named
`log_ingest`, and the routing key `ingest`. The Ingest API publishes a JSON job containing
`job_id`, `file_name`, and the raw syslog `payload`. Workers consume from the same queue
with `prefetch_count=1`, creating a competing-consumer pattern where RabbitMQ distributes
batches across available workers.

Workers use manual acknowledgements. A worker acknowledges a message only after parsing
and storage have completed. If a worker is killed before acknowledging a job, RabbitMQ can
redeliver the message to another available worker. This reduces synchronous blocking and
supports autonomous recovery during node failure.

### C. State Management and Consistency

Each syslog line is parsed into the following fields: timestamp, hostname, process,
severity, and message. The parser uses regular expressions to extract standard syslog
components. If a line does not match the expected pattern, it is still stored with the raw
message and a fallback process value, preventing accidental data loss from malformed log
lines.

MongoDB stores parsed records in the `logs` collection. Each line receives a deterministic
`dedupe_key` based on the job identifier and line number. A unique index on this key
prevents duplicate records during RabbitMQ redelivery. This is important because a killed
worker may cause a message to be delivered more than once.

The data layer is partitioned through MongoDB sharding. Application services connect to
`mongos`, and MongoDB routes writes and queries to the correct shards. The `logs`
collection is sharded by `dedupe_key`, distributing records across the two shard replica
sets.

The `PURGE` operation uses a lock document in the `locks` collection. Read, write, and
purge operations acquire this lock so that purge does not run concurrently with active
reads or writes. This implements a simple distributed coordination mechanism suitable for
the project demonstration.

### D. Deployment and Containerization

The entire ecosystem is orchestrated through `docker-compose.yml`. The manifest starts:

- RabbitMQ with management UI
- Ingest API
- Query API
- Three worker containers
- Three MongoDB config servers
- Two shard replica sets with two nodes each
- A `mongos` router
- Initialization jobs for replica sets and sharding

The MongoDB initialization scripts wait until the database nodes are reachable before
running replica-set and sharding commands. This avoids startup race conditions during
one-command deployment.

Default local ports are:

- `8081`: Ingest API
- `8080`: Query API, `/logs`, `/nodes`, and `PURGE`
- `15672`: RabbitMQ management UI
- `27017`: MongoDB `mongos` router

On the provided VM infrastructure, external ports map to the internal service ports. For
example, Server1 exposes the Ingest API at `103.231.240.136:31723` and the Query API at
`103.231.240.136:31523`.

## III. Test and Result

### A. Core Functionality and Performance

Core functionality was validated through manual CLI commands and browser inspection
pages. A sample syslog file was ingested through the Ingest API. Worker containers
processed the queued job and wrote parsed records to MongoDB. The Query API then returned
matching records for host, daemon, severity, date, and keyword searches.

Example test commands:

```text
INGEST ./sample.log http://localhost:8081
QUERY http://localhost:8080 SEARCH_HOST web-1
QUERY http://localhost:8080 SEARCH_DAEMON sshd
QUERY http://localhost:8080 SEARCH_SEVERITY error
QUERY http://localhost:8080 SEARCH_KEYWORD password
QUERY http://localhost:8080 COUNT_KEYWORD password
PURGE http://localhost:8080
```

The `/logs` page was used to inspect stored records, while `/nodes` confirmed active
worker metadata. RabbitMQ's management UI was used to confirm that `log_ingest` received
messages and that workers consumed queued jobs.

**Table I: Core Functionality Results**

| Test | Expected Result | Observed Result |
|---|---|---|
| Ingest sample log | API returns accepted job ID | [Insert result] |
| Search by host | Matching host records returned | [Insert result] |
| Search by daemon | Matching process records returned | [Insert result] |
| Search by severity | Matching severity records returned | [Insert result] |
| Count keyword | Aggregate keyword count returned | [Insert result] |
| Purge logs | Records removed; later query returns zero | [Insert result] |

### B. Fault Tolerance and Chaos Testing

Fault tolerance was tested using `scripts/chaos_test.py`. The script purges old logs,
generates multiple syslog batches, starts concurrent ingestion, stops `worker-1` during
processing, restarts the worker, and waits for the system to recover. It then verifies
the expected keyword count and checks MongoDB for duplicate `dedupe_key` values.

The expected behavior is:

- RabbitMQ keeps unacknowledged jobs durable while a worker is unavailable.
- Other workers continue processing queued messages.
- The stopped worker can be restarted without manual data repair.
- MongoDB's unique `dedupe_key` prevents duplicate processing.
- The final observed count equals the expected number of generated log lines.

Example command:

```text
python3 scripts/chaos_test.py
```

Expected final output:

```text
PASS: zero data loss, zero duplicate processing, autonomous worker recovery observed.
```

**Table II: Chaos Test Results**

| Metric | Expected | Observed |
|---|---:|---:|
| Generated log lines | [Insert expected count] | [Insert observed count] |
| Duplicate `dedupe_key` values | 0 | [Insert observed count] |
| Worker recovery | Automatic after restart | [Insert result] |
| RabbitMQ redelivery | Successful | [Insert result] |

## IV. Conclusion

The project successfully implements a decoupled distributed log analytics ecosystem. The
CLI forwarder, separate Ingest and Query APIs, RabbitMQ middleware, worker nodes, and
MongoDB sharded cluster work together to provide asynchronous ingestion and distributed
search. RabbitMQ manual acknowledgements and MongoDB duplicate prevention support
fault-tolerant recovery when a worker fails.

The main distributed computing challenges addressed were workload distribution,
partitioned storage, duplicate prevention, and coordination during destructive
operations. Future improvements may include replacing the simple lock document with a
more advanced distributed lock mechanism, adding authentication, converting the APIs to
FastAPI for OpenAPI documentation, adding live metrics dashboards, and expanding chaos
tests to include RabbitMQ and shard failures.

## References

[1] RabbitMQ, "RabbitMQ Documentation." [Online]. Available: https://www.rabbitmq.com/docs  
[2] MongoDB, "MongoDB Manual: Sharding." [Online]. Available: https://www.mongodb.com/docs/manual/sharding/  
[3] Docker, "Docker Compose Documentation." [Online]. Available: https://docs.docker.com/compose/  
[4] Python Software Foundation, "Python Documentation." [Online]. Available: https://docs.python.org/3/  

## AI Usage Disclosure

Generative AI assistance was used for syntax checking, debugging guidance, documentation
drafting, and organization of explanations. The final code, architecture decisions,
testing, and submitted documentation should be reviewed and validated by the group before
submission.
