# Distributed Mini-Splunk

Course machine project for a distributed log analytics ecosystem.

This repository is being built in slices:

1. CLI forwarder/client
2. API gateway and RabbitMQ middleware
3. Distributed worker nodes
4. Sharded MongoDB data layer
5. Fault-tolerance and chaos-test hardening

## Current Slice: CLI Client

Run the client locally:

```bash
python3 -m minisplunk.cli INGEST ./sample.log http://localhost:8080
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_HOST my-host
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_DATE "Jul 16"
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_DAEMON sshd
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_SEVERITY error
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_KEYWORD failed
python3 -m minisplunk.cli QUERY http://localhost:8080 COUNT_KEYWORD failed
python3 -m minisplunk.cli PURGE http://localhost:8080
```

The CLI targets an HTTP API gateway. The gateway enqueues ingestion jobs through
RabbitMQ and reads query results from the sharded MongoDB data layer.

## Run The Stack

Start RabbitMQ, the gateway, workers, and the MongoDB sharded cluster:

```bash
docker compose up --build
```

In another terminal:

```bash
python3 -m minisplunk.cli INGEST ./sample.log http://localhost:8080
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_HOST my-host
python3 -m minisplunk.cli QUERY http://localhost:8080 COUNT_KEYWORD failed
```

RabbitMQ management UI:

```text
http://localhost:15672
username: rabbituser
password: rabbit1234
```

Mini-Splunk browser views:

```text
http://localhost:8080/logs
http://localhost:8080/nodes
```

JSON versions:

```text
http://localhost:8080/logs?format=json
http://localhost:8080/nodes?format=json
```

## Linux VM Setup

These steps assume Docker and Docker Compose are already installed on the VM.

From the project directory:

```bash
docker compose down --remove-orphans
docker compose up --build
```

For a clean database reset during testing:

```bash
docker compose down --volumes --remove-orphans
docker compose up --build
```

If you run the CLI inside the VM, use `localhost` as the gateway address:

```bash
python3 -m minisplunk.cli INGEST ./sample.log http://localhost:8080
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_HOST web-1
```

If you run the CLI from another machine, use the VM's IP address:

```bash
python3 -m minisplunk.cli INGEST ./sample.log http://<VM_IP>:8080
python3 -m minisplunk.cli QUERY http://<VM_IP>:8080 SEARCH_HOST web-1
```

Ports used by the stack:

- `8080`: Mini-Splunk gateway, CLI API, `/logs`, and `/nodes`
- `15672`: RabbitMQ management UI
- `5672`: RabbitMQ broker inside Docker; expose externally only if needed
- `27017`: MongoDB `mongos` router for debugging

Recommended VM resources:

- Minimum: 4 GB RAM
- Recommended: 6-8 GB RAM

Verify the stack:

```bash
docker compose ps
docker compose exec mongos mongosh --eval 'sh.status()'
```

Manual smoke test:

```bash
printf 'Jul 16 15:20:01 web-1 sshd[123]: Failed password for root\nJul 16 15:21:10 db-1 mongod[55]: connection accepted\nJul 16 15:22:33 web-1 nginx[88]: request timeout warning\n' > sample.log

python3 -m minisplunk.cli INGEST ./sample.log http://localhost:8080
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_HOST web-1
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_SEVERITY error
python3 -m minisplunk.cli QUERY http://localhost:8080 COUNT_KEYWORD password
```

## Test

```bash
python3 -m unittest discover -v
```

## Current MongoDB Topology

- `mongos` query router exposed on `localhost:27017`
- 3 config servers in replica set `cfg`
- 2 shards: `shard1` and `shard2`
- Each shard has 2 MongoDB nodes
- `minisplunk.logs` is sharded by `dedupe_key`

## Open Decisions

- How much chaos-test automation to include in the final submission.
