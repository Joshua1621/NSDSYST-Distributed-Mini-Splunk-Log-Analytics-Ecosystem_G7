from __future__ import annotations

import argparse
import json
import shlex
import sys
from pathlib import Path
from typing import Sequence

from minisplunk.transport import GatewayClient, GatewayError, GatewayResponse


SEARCH_COMMANDS = {
    "SEARCH_DATE": "date",
    "SEARCH_HOST": "host",
    "SEARCH_DAEMON": "daemon",
    "SEARCH_SEVERITY": "severity",
    "SEARCH_KEYWORD": "keyword",
}


HELP_TEXT = """Available commands:
  help
    Show this help message.

  INGEST <file_path> <Ingest_API>
    Example: INGEST ./sample.log http://localhost:8081
    Public Server1 example: INGEST ./sample.log http://103.231.240.136:31723

  QUERY <Query_API> SEARCH_DATE "<date_string>"
    Example: QUERY http://localhost:8080 SEARCH_DATE "Jul 16"

  QUERY <Query_API> SEARCH_HOST <hostname>
    Example: QUERY http://localhost:8080 SEARCH_HOST web-1

  QUERY <Query_API> SEARCH_DAEMON <daemon_name>
    Example: QUERY http://localhost:8080 SEARCH_DAEMON sshd

  QUERY <Query_API> SEARCH_SEVERITY <severity_level>
    Example: QUERY http://localhost:8080 SEARCH_SEVERITY error

  QUERY <Query_API> SEARCH_KEYWORD <keyword>
    Example: QUERY http://localhost:8080 SEARCH_KEYWORD password

  QUERY <Query_API> COUNT_KEYWORD <keyword>
    Example: QUERY http://localhost:8080 COUNT_KEYWORD password

  PURGE <Query_API>
    Example: PURGE http://localhost:8080

  exit | quit
    Exit Mini Splunk CLI.
"""


class MiniSplunkArgumentParser(argparse.ArgumentParser):
    def error(self, message: str) -> None:
        raise ValueError(message)


def build_parser() -> argparse.ArgumentParser:
    parser = MiniSplunkArgumentParser(
        prog="minisplunk",
        description="CLI forwarder for the distributed Mini-Splunk project.",
    )
    subparsers = parser.add_subparsers(dest="command", required=True)

    ingest = subparsers.add_parser("INGEST", help="Send a local syslog file to the gateway.")
    ingest.add_argument("file_path", type=Path)
    ingest.add_argument("gateway_ip")

    query = subparsers.add_parser("QUERY", help="Run a distributed search through the gateway.")
    query.add_argument("gateway_ip")
    query.add_argument("query_type", choices=[*SEARCH_COMMANDS.keys(), "COUNT_KEYWORD"])
    query.add_argument("value")

    purge = subparsers.add_parser("PURGE", help="Delete all indexed log entries.")
    purge.add_argument("gateway_ip")

    return parser


def run(argv: Sequence[str], client_factory: type[GatewayClient] = GatewayClient) -> int:
    parser = build_parser()
    try:
        args = parser.parse_args(argv)
    except ValueError as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    try:
        if args.command == "INGEST":
            response = _run_ingest(args.file_path, args.gateway_ip, client_factory)
        elif args.command == "QUERY":
            response = _run_query(args.gateway_ip, args.query_type, args.value, client_factory)
        elif args.command == "PURGE":
            response = client_factory(args.gateway_ip).purge()
        else:
            parser.error(f"Unsupported command: {args.command}")
    except (GatewayError, FileNotFoundError, IsADirectoryError, PermissionError) as exc:
        print(f"error: {exc}", file=sys.stderr)
        return 1

    print(json.dumps(response.body, indent=2, sort_keys=True))
    return 0


def interactive(client_factory: type[GatewayClient] = GatewayClient) -> int:
    print("Mini Splunk CLI")
    print("Type 'help' to show commands. Type 'exit' or 'quit' to close.")

    while True:
        try:
            raw_command = input("Mini Splunk > ").strip()
        except (EOFError, KeyboardInterrupt):
            print()
            return 0

        if not raw_command:
            continue

        lowered = raw_command.lower()
        if lowered in {"exit", "quit"}:
            return 0
        if lowered == "help":
            print(HELP_TEXT)
            continue

        try:
            argv = shlex.split(raw_command)
        except ValueError as exc:
            print(f"error: {exc}", file=sys.stderr)
            continue

        run(argv, client_factory)


def _run_ingest(
    file_path: Path,
    gateway_ip: str,
    client_factory: type[GatewayClient],
) -> GatewayResponse:
    if not file_path.is_file():
        raise FileNotFoundError(f"Syslog file does not exist: {file_path}")
    return client_factory(gateway_ip).ingest(file_path)


def _run_query(
    gateway_ip: str,
    query_type: str,
    value: str,
    client_factory: type[GatewayClient],
) -> GatewayResponse:
    client = client_factory(gateway_ip)
    if query_type == "COUNT_KEYWORD":
        return client.count_keyword(value)
    return client.search(SEARCH_COMMANDS[query_type], value)


def main() -> None:
    raise SystemExit(run(sys.argv[1:]))


if __name__ == "__main__":
    main()
