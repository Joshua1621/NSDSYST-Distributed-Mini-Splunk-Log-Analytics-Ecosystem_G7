# Distributed Mini-Splunk

Course machine project for a distributed log analytics ecosystem.

This repository is being built in slices:

1. CLI forwarder/client
2. API gateway and RabbitMQ middleware
3. Distributed worker nodes
4. Sharded MongoDB data layer
5. Fault-tolerance and chaos-test hardening

## Current Slice: CLI Client

Run the client locally:

```bash
python3 -m minisplunk.cli INGEST ./sample.log http://localhost:8080
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_HOST my-host
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_DATE "Jul 16"
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_DAEMON sshd
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_SEVERITY error
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_KEYWORD failed
python3 -m minisplunk.cli QUERY http://localhost:8080 COUNT_KEYWORD failed
python3 -m minisplunk.cli PURGE http://localhost:8080
```

The CLI targets an HTTP API gateway. The gateway enqueues ingestion jobs through
RabbitMQ and reads query results from the sharded MongoDB data layer.

## Run The Stack

Start RabbitMQ, the gateway, workers, and the MongoDB sharded cluster:

```bash
docker compose up --build
```

In another terminal:

```bash
python3 -m minisplunk.cli INGEST ./sample.log http://localhost:8080
python3 -m minisplunk.cli QUERY http://localhost:8080 SEARCH_HOST my-host
python3 -m minisplunk.cli QUERY http://localhost:8080 COUNT_KEYWORD failed
```

RabbitMQ management UI:

```text
http://localhost:15672
username: rabbituser
password: rabbit1234
```

Mini-Splunk browser views:

```text
http://localhost:8080/logs
http://localhost:8080/nodes
```

JSON versions:

```text
http://localhost:8080/logs?format=json
http://localhost:8080/nodes?format=json
```

## Test

```bash
python3 -m unittest discover -v
```

## Current MongoDB Topology

- `mongos` query router exposed on `localhost:27017`
- 3 config servers in replica set `cfg`
- 2 shards: `shard1` and `shard2`
- Each shard has 2 MongoDB nodes
- `minisplunk.logs` is sharded by `dedupe_key`

## Open Decisions

- How much chaos-test automation to include in the final submission.
