from __future__ import annotations

from minisplunk.cli import interactive


if __name__ == "__main__":
    raise SystemExit(interactive())
