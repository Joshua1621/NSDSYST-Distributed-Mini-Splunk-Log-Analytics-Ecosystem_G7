from __future__ import annotations

import argparse
import json
import subprocess
import sys
import time
from concurrent.futures import ThreadPoolExecutor, as_completed
from pathlib import Path

PROJECT_ROOT = Path(__file__).resolve().parents[1]
if str(PROJECT_ROOT) not in sys.path:
    sys.path.insert(0, str(PROJECT_ROOT))

from minisplunk.transport import GatewayClient, GatewayError


MARKER = "CHAOS_MARKER"


def build_parser() -> argparse.ArgumentParser:
    parser = argparse.ArgumentParser(description="Run a Mini-Splunk worker failure chaos test.")
    parser.add_argument("--ingest-url", default="http://localhost:8081")
    parser.add_argument("--query-url", default="http://localhost:8080")
    parser.add_argument("--worker", default="worker-1")
    parser.add_argument("--batches", type=int, default=8)
    parser.add_argument("--lines-per-batch", type=int, default=250)
    parser.add_argument("--timeout-seconds", type=int, default=90)
    parser.add_argument("--keep-files", action="store_true")
    return parser


def main() -> int:
    args = build_parser().parse_args()
    expected_lines = args.batches * args.lines_per_batch
    generated_dir = Path("tmp") / "chaos"
    generated_dir.mkdir(parents=True, exist_ok=True)

    print("== Mini-Splunk Chaos Test ==")
    print(f"Ingest API: {args.ingest_url}")
    print(f"Query API:  {args.query_url}")
    print(f"Worker to interrupt: {args.worker}")
    print(f"Expected log lines: {expected_lines}")

    query_client = GatewayClient(args.query_url, timeout_seconds=60)
    ingest_client = GatewayClient(args.ingest_url, timeout_seconds=60)

    print("\n[1/6] Purging old logs...")
    query_client.purge()

    print("[2/6] Generating syslog batches...")
    batch_files = generate_batches(generated_dir, args.batches, args.lines_per_batch)

    print("[3/6] Starting concurrent ingestion and stopping one worker...")
    with ThreadPoolExecutor(max_workers=min(4, args.batches)) as executor:
        futures = []
        for index, batch_file in enumerate(batch_files):
            futures.append(executor.submit(ingest_client.ingest, batch_file))
            if index == 1:
                stop_worker(args.worker)
                time.sleep(2)

        for future in as_completed(futures):
            future.result()

    print("[4/6] Restarting interrupted worker...")
    start_worker(args.worker)

    print("[5/6] Waiting for RabbitMQ redelivery and worker recovery...")
    observed_count = wait_for_count(query_client, expected_lines, args.timeout_seconds)

    print("[6/6] Checking MongoDB duplicate keys...")
    mongo_stats = mongo_duplicate_report()

    if not args.keep_files:
        for batch_file in batch_files:
            batch_file.unlink(missing_ok=True)

    print("\n== Chaos Test Result ==")
    print(f"Expected {MARKER} count: {expected_lines}")
    print(f"Observed {MARKER} count: {observed_count}")
    print(f"MongoDB total docs:       {mongo_stats['total_docs']}")
    print(f"Duplicate dedupe_key(s):  {mongo_stats['duplicate_keys']}")

    if observed_count != expected_lines:
        print("FAIL: data loss or incomplete recovery detected.")
        return 1
    if mongo_stats["duplicate_keys"] != 0:
        print("FAIL: duplicate processing detected.")
        return 1

    print("PASS: zero data loss, zero duplicate processing, autonomous worker recovery observed.")
    return 0


def generate_batches(directory: Path, batches: int, lines_per_batch: int) -> list[Path]:
    files = []
    for batch in range(1, batches + 1):
        file_path = directory / f"chaos_batch_{batch}.log"
        lines = []
        for line_number in range(1, lines_per_batch + 1):
            host = f"chaos-host-{(line_number % 5) + 1}"
            daemon = "sshd" if line_number % 2 == 0 else "nginx"
            severity_text = "Failed password" if line_number % 10 == 0 else "request completed"
            lines.append(
                f"Jul 16 15:{batch:02d}:{line_number % 60:02d} "
                f"{host} {daemon}[{1000 + line_number}]: {MARKER} batch={batch} line={line_number} {severity_text}\n"
            )
        file_path.write_text("".join(lines), encoding="utf-8")
        files.append(file_path)
    return files


def stop_worker(worker: str) -> None:
    print(f"      stopping {worker}...")
    run_command(["docker", "compose", "stop", worker])


def start_worker(worker: str) -> None:
    print(f"      starting {worker}...")
    run_command(["docker", "compose", "start", worker])


def wait_for_count(client: GatewayClient, expected: int, timeout_seconds: int) -> int:
    deadline = time.monotonic() + timeout_seconds
    last_count = 0
    while time.monotonic() < deadline:
        try:
            response = client.count_keyword(MARKER)
        except GatewayError as exc:
            print(f"      query not ready yet: {exc}")
            time.sleep(2)
            continue

        last_count = int(response.body.get("count", 0))
        print(f"      observed {last_count}/{expected}")
        if last_count >= expected:
            return last_count
        time.sleep(2)
    return last_count


def mongo_duplicate_report() -> dict[str, int]:
    script = """
const totalDocs = db.logs.countDocuments({});
const duplicateGroups = db.logs.aggregate([
  { $group: { _id: "$dedupe_key", count: { $sum: 1 } } },
  { $match: { count: { $gt: 1 } } },
  { $count: "duplicate_keys" }
]).toArray();
print(JSON.stringify({
  total_docs: totalDocs,
  duplicate_keys: duplicateGroups[0] ? duplicateGroups[0].duplicate_keys : 0
}));
"""
    result = run_command(
        ["docker", "compose", "exec", "-T", "mongos", "mongosh", "minisplunk", "--quiet", "--eval", script],
        capture=True,
    )
    return json.loads(result.stdout.strip().splitlines()[-1])


def run_command(command: list[str], capture: bool = False) -> subprocess.CompletedProcess[str]:
    try:
        return subprocess.run(
            command,
            check=True,
            text=True,
            stdout=subprocess.PIPE if capture else None,
            stderr=subprocess.PIPE if capture else None,
        )
    except FileNotFoundError as exc:
        raise RuntimeError(f"Command not found: {command[0]}") from exc
    except subprocess.CalledProcessError as exc:
        if capture:
            print(exc.stdout, file=sys.stdout)
            print(exc.stderr, file=sys.stderr)
        raise


if __name__ == "__main__":
    raise SystemExit(main())
