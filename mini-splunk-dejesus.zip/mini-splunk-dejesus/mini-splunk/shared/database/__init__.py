"""
Shared database components.
"""